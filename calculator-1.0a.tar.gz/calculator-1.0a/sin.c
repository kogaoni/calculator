#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int
main(int argc, char *argv[]){
	double i;
	
	if (argc!=2)
		printf("arg shows a -1.0 through 1.0 floating point value\n");

	i=fabs(atof(argv[1]));
	printf("cosine of value: %f\n", sin(i));

	return 0;
}

