#include <stdlib.h>
#include <stdio.h>

int
main(int argc, char *argv[]){
	long int a;
	long int answer;

	if(argc!=2){
		return 1;
	}

	a=atol(argv[1]);
	answer=a*a*a;
	printf("%ld\n", answer);
	return 0;
}
