#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char *argv[]){
	long int i;
	long int counter;
	long int answer=1;

	if(argc!=2)
		return 1;
	i=atol(argv[1]);
	for(counter=1; counter!=(i+1); counter++)
		answer*=counter;
	printf("%ld\n", answer);
	return 0;
}

