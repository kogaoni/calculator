#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int
main(int argc, char *argv[]){
	double x, y;
	double z;

	if(argc != 4)
		fprintf(stderr, "usage: fma [real x] [real y] [real z]\n");

	
	x=atof(argv[1]);
	y=atof(argv[2]);
	z=atof(argv[3]);

	printf("answer: %d\n", fma(x, y, z));

	return 0;
}
